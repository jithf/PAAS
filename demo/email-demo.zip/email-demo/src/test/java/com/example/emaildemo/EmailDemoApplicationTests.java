package com.example.emaildemo;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.test.context.junit4.SpringRunner;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.mail.internet.MimeMessage;


@RunWith(SpringRunner.class)
@SpringBootTest
public class EmailDemoApplicationTests {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private TemplateEngine templateEngine;

    @Test
    @Ignore
    public void sendSimpleMail() throws Exception {
        SimpleMailMessage message= new SimpleMailMessage();
        message.setFrom("2212557736@qq.com");
        message.setTo("13260900973@163.com");
        message.setSubject("test");
        message.setText("www.baidu.com");

        mailSender.send(message);
    }

    @Test
    public void sendTemplateMail() throws Exception {
        MimeMessage mimeMailMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMailMessage,true);
        helper.setFrom("2212557736@qq.com");
        helper.setTo("13260900973@163.com");
        helper.setSubject("template");

        Context context = new Context();
        //context.setVariable("register_link", "www.baidu.com");
        String emailContent = templateEngine.process("mail", context);
        helper.setText(emailContent,true);

        mailSender.send(mimeMailMessage);
    }
    @Test
    public void contextLoads() {
    }

}
