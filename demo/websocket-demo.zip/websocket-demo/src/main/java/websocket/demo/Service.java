package websocket.demo;

public class Service {
    public String result() {
        return "hello world";
    }
}
