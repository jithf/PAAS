package websocket.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import websocket.demo.WebSocketServer;

import java.io.IOException;

@RestController
public class TestController {
    @Autowired
    WebSocketServer webSocketServer;
    @RequestMapping("/test")
    public String test() throws IOException {
        String s = "hello s";
       webSocketServer.sendMessage(s);
        return "end";
    }
}
