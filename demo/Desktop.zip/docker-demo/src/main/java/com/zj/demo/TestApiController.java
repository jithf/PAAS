package com.zj.demo;

import com.spotify.docker.client.DefaultDockerClient;
import com.spotify.docker.client.DockerClient;
import com.spotify.docker.client.LogStream;
import com.spotify.docker.client.exceptions.DockerException;
import com.spotify.docker.client.messages.*;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.*;

/**
 * @Auther: zj
 * @Date: 2018/7/1 09:08
 * @Description:
 */
@RestController
public class TestApiController {

    /**
     * @Auther: zj
     * @Date: 2018/7/5 09:49
     * @Description: create a docker (适用于java容器)
     * @return
     * 注意：java镜像是没有默认端口的
     */
    @GetMapping("/createContainerJava")
    public String createContainerJava(@RequestParam("imageName") String imageName,
                                      @RequestParam("port") String modifyPort) {

        try {
            // Create a client  by using the builder 通过builder连接一个客户机
            final DockerClient docker = DefaultDockerClient.builder()
                    .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                    // Set various options
                    .build();
            final List<Image> quxImages = docker.listImages( DockerClient.ListImagesParam.allImages() );
            Integer status = 0;
            System.out.println(imageName);
            //TODO 可能id一样，tag不一样。es:[java:8,java:8u111].这边要修改
            for (Image quxImage : quxImages) {
                if (quxImage.repoTags().toString().equals( String.format( "[" + imageName.toString() + "]" ) )) {
                    System.out.println( quxImage.repoTags().toString() );
                    status = status + 1;
                } else {
                    status = status;
                }
            }
            if (status != 0) {
                System.out.println( "该镜像已存在" );
            } else {
                System.out.println( "该镜像不存在" );
                docker.pull( imageName );//拉取镜像
            }
            //docker.pull( imageName );
            System.out.println( "+++++" );

            // TODO 宿主机端口 要随机分配
            String exposedPort = "" + modifyPort;//宿主机端口

//            //获取镜像默认端口
//            final ImageInfo info = docker.inspectImage(imageName);
//            Set containerPortSet = info.containerConfig().exposedPorts();//镜像默认端口
//            String str = StringUtils.join(containerPortSet.toArray(), ";");//set to string
//            System.out.println( str );
//            Iterator<Set> iterator =  containerPortSet.iterator();
//            while (iterator.hasNext()) {
//                System.out.println(iterator.next());
//                String str2 = iterator.next();
//                System.out.println( str2 );
//            }
            //String containerPort = "8080" + "/tcp";//镜像默认端口
            //TODO 该端口是用户上传项目的端口（server.port）
            String containerPort = "8080";//容器暴露端口

            //将宿主机的端口 与 容器暴露端口 绑定
            final Map<String, List<PortBinding>> portBindings = new HashMap<String, List<PortBinding>>();
            List<PortBinding> hostPorts = new ArrayList<PortBinding>();
            hostPorts.add(PortBinding.of("0.0.0.0", exposedPort));
            // todo 很重要这里"8080/tcp"表示8080必须是容器的默认端口，才能绑定。"8080"表明指定容器的暴露端口，即可绑定
            portBindings.put(containerPort,hostPorts);

            //实现文件挂载（挂载成功目录下的文件实现共享）
            HostConfig.Bind bind = new HostConfig.Bind() {
                @Override
                public String to() {
                    return "/www";
                }//容器内的目录。如果不存在，会自动新建

                @Override
                public String from() {
                    return "/root/java-test";
                }//宿主机的目录（即存放项目的目录），一定要事先建立好，不然会报错

                @Override
                public Boolean readOnly() {
                    return true;
                }

                @Override
                public Boolean noCopy() {
                    return false;
                }

                @Override
                public Boolean selinuxLabeling() {
                    return false;
                }//
            };

            final HostConfig hostConfig = HostConfig.builder()
                    .binds(bind)//实现文件挂载
                    .portBindings( portBindings )//实现端口绑定
                    .build();
            System.out.println( hostConfig );

            // Create container with exposed ports 创建带有暴露端口的容器
            final ContainerConfig containerConfig = ContainerConfig.builder()
                    .hostConfig( hostConfig )
                    .image( imageName )
                    .exposedPorts( containerPort )//暴露指定端口
                    //.cmd( "sh", "-c", "while :; do sleep 1; done" )//让容器创建后不默认关闭
                    .tty( true )//让容器创建后不默认关闭
                    .build();
            final ContainerCreation creation = docker.createContainer( containerConfig );

            final String id = creation.id();//获得容器的id

            System.out.println( creation );
            System.out.println( id );

            // Inspect container 获得容器的详细信息
            final ContainerInfo infoC = docker.inspectContainer( id );
            System.out.println( ">>>>>>>>>>>>>>>>>>>" );
            System.out.println( infoC );

            // Start container
            docker.startContainer( id );

            // Exec command inside running container with attached STDOUT and STDERR  执行命令在正运行容器带有附加的STDUT和STDER
            final String[] command = {"ls"};
            final ExecCreation execCreation = docker.execCreate(
                    id, command, DockerClient.ExecCreateParam.attachStdout() );
            final LogStream output = docker.execStart( execCreation.id() );
            final String execOutput = output.readFully();

            System.out.println( execOutput );

            // Close the docker client 关闭这个容器客户机
            docker.close();

            return infoC.toString();

        }catch (Exception e) {
            e.printStackTrace(); //printStackTrace()方法的意思是：在命令行打印异常信息在程序中出错的位置及原因
        }

        return null;
    }

    /**
     * @Auther: zj
     * @Date: 2018/7/6 09:49
     * @Description: create a docker (比如创建java容器，同时连接mysql容器)
     * @return
     * 注意：java镜像是没有默认端口的
     */
    @GetMapping("/createContainerJavaWithMysql")
    public String createContainerJavaWithMysql(@RequestParam("imageName") String imageName,
                                      @RequestParam("port") String modifyPort) {

        try {
            // Create a client  by using the builder 通过builder连接一个客户机
            final DockerClient docker = DefaultDockerClient.builder()
                    .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                    // Set various options
                    .build();
            final List<Image> quxImages = docker.listImages( DockerClient.ListImagesParam.allImages() );
            Integer status = 0;
            System.out.println(imageName);
            //TODO 可能id一样，tag不一样。es:[java:8,java:8u111].这边要修改
            for (Image quxImage : quxImages) {
                if (quxImage.repoTags().toString().equals( String.format( "[" + imageName.toString() + "]" ) )) {
                    System.out.println( quxImage.repoTags().toString() );
                    status = status + 1;
                } else {
                    status = status;
                }
            }
            if (status != 0) {
                System.out.println( "该镜像已存在" );
            } else {
                System.out.println( "该镜像不存在" );
                docker.pull( imageName );//拉取镜像
            }
            //docker.pull( imageName );
            System.out.println( "+++++" );

            // TODO 宿主机端口 要随机分配
            String exposedPort = "" + modifyPort;//宿主机端口

//            //获取镜像默认端口
//            final ImageInfo info = docker.inspectImage(imageName);
//            Set containerPortSet = info.containerConfig().exposedPorts();//镜像默认端口
//            String str = StringUtils.join(containerPortSet.toArray(), ";");//set to string
//            System.out.println( str );
//            Iterator<Set> iterator =  containerPortSet.iterator();
//            while (iterator.hasNext()) {
//                System.out.println(iterator.next());
//                String str2 = iterator.next();
//                System.out.println( str2 );
//            }
            //String containerPort = "8080" + "/tcp";//镜像默认端口
            //TODO 该端口是用户上传项目的端口（server.port）
            String containerPort = "8080";//容器暴露端口

            //将宿主机的端口 与 容器暴露端口 绑定
            final Map<String, List<PortBinding>> portBindings = new HashMap<String, List<PortBinding>>();
            List<PortBinding> hostPorts = new ArrayList<PortBinding>();
            hostPorts.add(PortBinding.of("0.0.0.0", exposedPort));
            // todo 很重要这里"8080/tcp"表示8080必须是容器的默认端口，才能绑定。"8080"表明指定容器的暴露端口，即可绑定
            portBindings.put(containerPort,hostPorts);

            //实现文件挂载（挂载成功目录下的文件实现共享）
            HostConfig.Bind bind = new HostConfig.Bind() {
                @Override
                public String to() {
                    return "/qqq";
                }//容器内的目录。如果不存在，会自动新。

                @Override
                public String from() {
                    return "/root/java-test";
                }//宿主机的目录（即存放项目的目录），一定要事先建立好，不然会报错

                @Override
                public Boolean readOnly() {
                    return true;
                }

                @Override
                public Boolean noCopy() {
                    return false;
                }

                @Override
                public Boolean selinuxLabeling() {
                    return false;
                }//
            };

            String link_mysql = String.format( "08449aa44992097676f3e8dc9190c13ceee59b56b789863188882b968709f5f6" // todo 连接容器的id或名称。该容器id应该是前端传入
                                                +":"
                                                +"zjMysql" //别称
                                            );

            final HostConfig hostConfig = HostConfig.builder()
                    .links( link_mysql )//连接容器
                    .binds(bind)//实现文件挂载
                    .portBindings( portBindings )//实现端口绑定
                    .build();
            System.out.println( hostConfig );

            // Create container with exposed ports 创建带有暴露端口的容器
            final ContainerConfig containerConfig = ContainerConfig.builder()
                    .hostConfig( hostConfig )
                    .image( imageName )
                    .exposedPorts( containerPort )//暴露指定端口
                    .cmd( "sh", "-c", "while :; do sleep 1; done" )//让容器创建后不默认关闭
                    .build();
            final ContainerCreation creation = docker.createContainer( containerConfig );

            final String id = creation.id();//获得容器的id

            System.out.println( creation );
            System.out.println( id );

            // Inspect container 获得容器的详细信息
            final ContainerInfo infoC = docker.inspectContainer( id );
            System.out.println( ">>>>>>>>>>>>>>>>>>>" );
            System.out.println( infoC );

            // Start container
            docker.startContainer( id );

            // Exec command inside running container with attached STDOUT and STDERR  执行命令在正运行容器带有附加的STDUT和STDER
            final String[] command = {"ls"};
            final ExecCreation execCreation = docker.execCreate(
                    id, command, DockerClient.ExecCreateParam.attachStdout() );
            final LogStream output = docker.execStart( execCreation.id() );
            final String execOutput = output.readFully();

            System.out.println( execOutput );

            // Close the docker client 关闭这个容器客户机
            docker.close();

            return infoC.toString();

        }catch (Exception e) {
            e.printStackTrace(); //printStackTrace()方法的意思是：在命令行打印异常信息在程序中出错的位置及原因
        }

        return null;
    }



}
