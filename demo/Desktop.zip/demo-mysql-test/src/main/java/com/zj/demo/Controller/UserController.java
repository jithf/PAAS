package com.zj.demo.Controller;

import com.zj.demo.Repository.UserRepository;
import com.zj.demo.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Auther: zj
 * @Date: 2018/7/6 17:14
 * @Description:
 */
@RestController
public class UserController {

    @Autowired
    UserRepository userRepository;

    @GetMapping("/")
    public String main() {
        return "hello world!!!";
    }

    @GetMapping("/getUser")
    public Object getUser() {
        List<User> user =userRepository.findAll();
        return user;
    }

}
