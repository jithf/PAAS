package com.zj.demo.domain;

import javax.persistence.*;
import javax.validation.constraints.Size;

/**
 * @Auther: zj
 * @Date: 2018/7/6 16:59
 * @Description:
 */
@Entity
public class User {
    @Id // 主键
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 自增长策略
    private Long id; // 用户的唯一标识

    private String username; // 用户账号，用户登录时的唯一标识

    @Size(max = 100)
    @Column(length = 100)
    private String password; // 登录时密码

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



}
