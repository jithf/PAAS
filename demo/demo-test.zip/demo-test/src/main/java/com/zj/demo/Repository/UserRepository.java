package com.zj.demo.Repository;

import com.zj.demo.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @Auther: zj
 * @Date: 2018/7/6 17:10
 * @Description:
 */
public interface UserRepository extends JpaRepository<User,Long> {
}
