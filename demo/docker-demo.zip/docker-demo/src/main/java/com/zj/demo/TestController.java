package com.zj.demo;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.UnmodifiableIterator;
import com.spotify.docker.client.DefaultDockerClient;
import com.spotify.docker.client.DockerClient;
import com.spotify.docker.client.LogStream;
import com.spotify.docker.client.exceptions.DockerException;
import com.spotify.docker.client.messages.*;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.*;

/**
 * @Auther: zj
 * @Date: 2018/6/28 09:43
 * @Description:简单的测试
 */
@RestController
public class TestController {

    /**
     * @Auther: zj
     * @Date: 2018/6/28 09:49
     * @Description:create a docker client
     * @return
     */
    @GetMapping("/createClient")
    public String createClient() throws DockerException, InterruptedException {

        try {
            // Create a client  by using the builder 通过builder连接一个客户机
            final DockerClient docker = DefaultDockerClient.builder()
                    .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                    // Set various options
                    .build();

            // Pull an image 拉取镜像
            //docker.pull("busybox"); 这里我docker已经存在了，就不拉了

            // Bind container ports to host ports 将容器端口绑定到主机端口
            final String[] ports = {"8080", "23"};
            final Map<String, List<PortBinding>> portBindings = new HashMap<>();
            for (String port : ports) {
                List<PortBinding> hostPorts = new ArrayList<>();
                hostPorts.add( PortBinding.of( "0.0.0.0", port ) );
                portBindings.put( port, hostPorts );
            }

            // Bind container port 443 to an automatically allocated available host port. 将容器端口443绑定到自动分配的可用主机端口
            List<PortBinding> randomPort = new ArrayList<>();
            randomPort.add( PortBinding.randomPort( "0.0.0.0" ) );
            portBindings.put( "443", randomPort );

            final HostConfig hostConfig = HostConfig.builder().portBindings( portBindings ).build();

            System.out.println( hostConfig );

            // Create container with exposed ports 创建带有暴露端口的容器
            List<String> list = new ArrayList<>();
            final ContainerConfig containerConfig = ContainerConfig.builder()
                    .hostConfig( hostConfig )
                    .image( "java:8" ).exposedPorts( ports )
                    .cmd( "sh", "-c", "while :; do sleep 1; done" )
                    .build();

            final ContainerCreation creation = docker.createContainer( containerConfig );
            final String id = creation.id();

            System.out.println( creation );
            System.out.println( id );

            // Inspect container 检查容器
            final ContainerInfo info = docker.inspectContainer( id );
            System.out.println( info );

            // Start container
            docker.startContainer( id );

            // Exec command inside running container with attached STDOUT and STDERR  执行命令在正运行容器带有附加的STDUT和STDER
            final String[] command = {"ls"};
            final ExecCreation execCreation = docker.execCreate(
                    id, command, DockerClient.ExecCreateParam.attachStdout() );
            final LogStream output = docker.execStart( execCreation.id() );
            final String execOutput = output.readFully();

            System.out.println( execOutput );

            // Kill container 杀死这个进程
            //docker.killContainer( id );

            // Remove container 删除容器
           // docker.removeContainer( id );

            // Close the docker client 关闭这个容器客户机
            docker.close();

        } catch (Exception e) {
            e.printStackTrace(); //printStackTrace()方法的意思是：在命令行打印异常信息在程序中出错的位置及原因
        }


        return null;
    }

    /**
     * @Auther: zj
     * @Date: 2018/6/28 22:49
     * @Description: List images(查看docker已经pull下来的所有镜像)
     * @return
     */
    @GetMapping("/listImages")
    public String listImages() throws DockerException, InterruptedException {
        // Create a client  by using the builder 通过builder连接一个客户机
        final DockerClient docker = DefaultDockerClient.builder()
                .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                // Set various options
                .build();

        final List<Image> quxImages = docker.listImages( DockerClient.ListImagesParam.allImages());
        System.out.println( quxImages.get( 0 ).repoTags() );
        return quxImages.toString();
    }
    /**
     * @Auther: zj
     * @Date: 2018/6/28 22:49
     * @Description: search appointed images(搜索指定名称的所有镜像)
     * @return
     */
    @GetMapping("/searchAppointedImages")
    public String searchAppointedImages(@RequestParam("image") String image) throws DockerException, InterruptedException {
        // Create a client  by using the builder 通过builder连接一个客户机
        final DockerClient docker = DefaultDockerClient.builder()
                .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                // Set various options
                .build();

        final List<ImageSearchResult> searchResult = docker.searchImages(image);

        System.out.println( searchResult );
        return searchResult.toString();
    }


    /**
     * @Auther: zj
     * @Date: 2018/6/28 22:49
     * @Description: get appointed images information(获得指定名称镜像的详细信息)
     * @return
     */
    @GetMapping("/getImagesInfo")
    public Set getImagesInfo(@RequestParam("image") String modifyImage) throws DockerException, InterruptedException {
        // Create a client  by using the builder 通过builder连接一个客户机
        final DockerClient docker = DefaultDockerClient.builder()
                .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                // Set various options
                .build();
        final ImageInfo info = docker.inspectImage(modifyImage);
        System.out.println(info.containerConfig().exposedPorts());
        return info.containerConfig().exposedPorts();
    }


    /**
     * @Auther: zj
     * @Date: 2018/6/28 22:49
     * @Description: List running containers
     * @return
     */
    @GetMapping("/listRunningContainers")
    public String listRunningContainers() throws DockerException, InterruptedException {
        // Create a client  by using the builder 通过builder连接一个客户机
        final DockerClient docker = DefaultDockerClient.builder()
                .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                // Set various options
                .build();

        // List all running containers.
        final List<Container> containers = docker.listContainers();

        return containers.toString();
    }

    /**
     * @Auther: zj
     * @Date: 2018/6/28 22:55
     * @Description: List all containers including inactive containers
     * @return
     */
    @GetMapping("/listAllContainers")
    public String listAllContainers() throws DockerException, InterruptedException {
        // Create a client  by using the builder 通过builder连接一个客户机
        final DockerClient docker = DefaultDockerClient.builder()
                .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                // Set various options
                .build();

        // List all containers including inactive containers
        final List<Container> containers = docker.listContainers( DockerClient.ListContainersParam.allContainers());

        return containers.toString();
    }

    /**
     * @Auther: zj
     * @Date: 2018/6/28 22:49
     * @Description: create a container,and start it(前提条件是镜像默认端口是一个，如果多个可能出错)(适用于tomcat)
     * @return
     */
    @GetMapping("/createContainer")
    public String createContainer(@RequestParam("imageName") String imageName,
                                  @RequestParam("port") String modifyPort) {
        try {
            // Create a client  by using the builder 通过builder连接一个客户机
            final DockerClient docker = DefaultDockerClient.builder()
                    .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                    // Set various options
                    .build();
            final List<Image> quxImages = docker.listImages( DockerClient.ListImagesParam.allImages());
            Integer status = 0;
            //System.out.println(imageName);
            for(Image quxImage:quxImages) {
                if (quxImage.repoTags().toString().equals( String.format( "[" +imageName.toString()+"]") )){
                    //System.out.println( "已存在" );
                    status= status +1;
                }
                else {
                    status = status;
                }
            }
            if(status !=0){
                System.out.println( "该镜像已存在" );
            }
            else {
                System.out.println( "该镜像不存在" );
                docker.pull( imageName );//拉取镜像
            }
            //docker.pull( imageName );
            System.out.println( "++++" );

            // TODO 宿主机端口 要随机分配
            String exposedPort = "" + modifyPort;//宿主机端口

            //获取镜像默认端口
            final ImageInfo info = docker.inspectImage(imageName);
            Set containerPortSet = info.containerConfig().exposedPorts();//镜像默认端口
            String str = StringUtils.join(containerPortSet.toArray(), ";");//set to string
            System.out.println( str );

//            Iterator<Set> iterator =  containerPortSet.iterator();
//            while (iterator.hasNext()) {
//                System.out.println(iterator.next());
//                String str2 = iterator.next();
//                System.out.println( str2 );
//            }
            //String containerPort = "8080" + "/tcp";//镜像默认端口
            String containerPort = str;//容器暴露端口
            String containerPortName = str.split( "/" )[0];//容器的预暴露端口名
            //final String[] ports = {"8080" +""};

            //将宿主机的端口 与 容器暴露端口 绑定
            final Map<String, List<PortBinding>> portBindings = new HashMap<String, List<PortBinding>>();
            List<PortBinding> hostPorts = new ArrayList<PortBinding>();
            hostPorts.add(PortBinding.of("0.0.0.0", exposedPort));
            portBindings.put(containerPort + "", hostPorts);

            final HostConfig hostConfig = HostConfig.builder().portBindings( portBindings ).build();

            System.out.println( hostConfig );

            // Create container with exposed ports 创建带有暴露端口的容器
            List<String> list = new ArrayList<>();
            final ContainerConfig containerConfig = ContainerConfig.builder()
                    .hostConfig( hostConfig )
                    .image( imageName )
                    .exposedPorts( containerPortName )//暴露指定端口
                    //.cmd( "sh", "-c", "while :; do sleep 1; done" )//不加有默认cmd,java容器一定要加
                    .build();
            final ContainerCreation creation = docker.createContainer( containerConfig );

            final String id = creation.id();//获得容器的id

            System.out.println( creation );
            System.out.println( id );

            // Inspect container 获得容器的详细信息
            final ContainerInfo infoC = docker.inspectContainer( id );
            System.out.println( ">>>>>>>>>>>>>>>>>>>" );
            System.out.println( infoC );

            // Start container
            docker.startContainer( id );

            // Exec command inside running container with attached STDOUT and STDERR  执行命令在正运行容器带有附加的STDUT和STDER
            final String[] command = {"ls"};
            final ExecCreation execCreation = docker.execCreate(
                    id, command, DockerClient.ExecCreateParam.attachStdout() );
            final LogStream output = docker.execStart( execCreation.id() );
            final String execOutput = output.readFully();

            System.out.println( execOutput );

            // Kill container 杀死这个进程
            //docker.killContainer( id );

            // Remove container 删除容器
            //docker.removeContainer( id );

            // Close the docker client 关闭这个容器客户机
            docker.close();

            return infoC.toString();

        } catch (Exception e) {
            e.printStackTrace(); //printStackTrace()方法的意思是：在命令行打印异常信息在程序中出错的位置及原因
        }
        return null;
    }

    /**
     * @Auther: zj
     * @Date: 2018/6/28 22:49
     * @Description: create a container with cmd,and start it(前提条件是镜像默认端口是一个，如果多个可能出错)(适用于mysql)
     * @return
     */
    @GetMapping("/createContainerWithCmd")
    public String createContainerWithCmd(@RequestParam("imageName") String imageName,
                                         @RequestParam("port") String modifyPort) {
        try {
            // Create a client  by using the builder 通过builder连接一个客户机
            final DockerClient docker = DefaultDockerClient.builder()
                    .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                    // Set various options
                    .build();
            final List<Image> quxImages = docker.listImages( DockerClient.ListImagesParam.allImages() );
            Integer status = 0;
            //System.out.println(imageName);
            for (Image quxImage : quxImages) {
                if (quxImage.repoTags().toString().equals( String.format( "[" + imageName.toString() + "]" ) )) {
                    //System.out.println( "已存在" );
                    status = status + 1;
                } else {
                    status = status;
                }
            }
            if (status != 0) {
                System.out.println( "该镜像已存在" );
            } else {
                System.out.println( "该镜像不存在" );
                docker.pull( imageName );//拉取镜像
            }
            //docker.pull( imageName );
            System.out.println( "++++" );

            // TODO 宿主机端口 要随机分配
            String exposedPort = "" + modifyPort;//宿主机端口

            //获取镜像默认端口
            final ImageInfo info = docker.inspectImage(imageName);
            Set containerPortSet = info.containerConfig().exposedPorts();//镜像默认端口
            String str = StringUtils.join(containerPortSet.toArray(), ";");//set to string
            System.out.println( str );

//            Iterator<Set> iterator =  containerPortSet.iterator();
//            while (iterator.hasNext()) {
//                System.out.println(iterator.next());
//                String str2 = iterator.next();
//                System.out.println( str2 );
//            }
            //String containerPort = "8080" + "/tcp";//镜像默认端口
            String containerPort = str;//容器暴露端口
            String containerPortName = str.split( "/" )[0];//容器的预暴露端口名
            //final String[] ports = {"8080" +""};

            //将宿主机的端口 与 容器暴露端口 绑定
            final Map<String, List<PortBinding>> portBindings = new HashMap<String, List<PortBinding>>();
            List<PortBinding> hostPorts = new ArrayList<PortBinding>();
            hostPorts.add(PortBinding.of("0.0.0.0", exposedPort));
            portBindings.put(containerPort + "", hostPorts);

            final HostConfig hostConfig = HostConfig.builder().portBindings( portBindings ).build();
            System.out.println( hostConfig );

            // Create container with exposed ports 创建带有暴露端口的容器
            List<String> list = new ArrayList<>();
            final ContainerConfig containerConfig = ContainerConfig.builder()
                    .hostConfig( hostConfig )
                    .image( imageName )
                    //.exposedPorts( "8080" ) //------------
                    .exposedPorts( containerPortName )//暴露指定端口
                    .env( "MYSQL_ROOT_PASSWORD=123456" ) //设置mysql初始密码
                    .build();
            final ContainerCreation creation = docker.createContainer( containerConfig );

            final String id = creation.id();//获得容器的id

            System.out.println( creation );
            System.out.println( id );

            // Inspect container 获得容器的详细信息
            final ContainerInfo infoC = docker.inspectContainer( id );
            System.out.println( ">>>>>>>>>>>>>>>>>>>" );
            System.out.println( infoC );

            // Start container
            docker.startContainer( id );

            // Exec command inside running container with attached STDOUT and STDERR  执行命令在正运行容器带有附加的STDUT和STDER
            final String[] command = {"ls"};
            final ExecCreation execCreation = docker.execCreate(
                    id, command, DockerClient.ExecCreateParam.attachStdout() );
            final LogStream output = docker.execStart( execCreation.id() );
            final String execOutput = output.readFully();

            System.out.println( execOutput );

            // Kill container 杀死这个进程
            //docker.killContainer( id );

            // Remove container 删除容器
            //docker.removeContainer( id );

            // Close the docker client 关闭这个容器客户机
            docker.close();

            return infoC.toString();

        }catch (Exception e) {
            e.printStackTrace(); //printStackTrace()方法的意思是：在命令行打印异常信息在程序中出错的位置及原因
        }

        return null;
    }

    /**
     * @Auther: zj
     * @Date: 2018/7/3 10:49
     * @Description: create a container and start it(前提条件是镜像默认端口是一个，如果多个可能出错)(适用于nginx,要实现文件挂载)
     * @return
     */
    @GetMapping("/createNginxContainer")
    public String createNginxContainer(@RequestParam("imageName") String imageName,
                                       @RequestParam("port") String modifyPort) {

        try {
            // Create a client  by using the builder 通过builder连接一个客户机
            final DockerClient docker = DefaultDockerClient.builder()
                    .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                    // Set various options
                    .build();
            final List<Image> quxImages = docker.listImages( DockerClient.ListImagesParam.allImages() );
            Integer status = 0;
            //System.out.println(imageName);
            for (Image quxImage : quxImages) {
                if (quxImage.repoTags().toString().equals( String.format( "[" + imageName.toString() + "]" ) )) {
                    //System.out.println( "已存在" );
                    status = status + 1;
                } else {
                    status = status;
                }
            }
            if (status != 0) {
                System.out.println( "该镜像已存在" );
            } else {
                System.out.println( "该镜像不存在" );
                docker.pull( imageName );//拉取镜像
            }
            //docker.pull( imageName );
            System.out.println( "+++++" );

            // TODO 宿主机端口 要随机分配
            String exposedPort = "" + modifyPort;//宿主机端口

            //获取镜像默认端口
            final ImageInfo info = docker.inspectImage(imageName);
            Set containerPortSet = info.containerConfig().exposedPorts();//镜像默认端口
            String str = StringUtils.join(containerPortSet.toArray(), ";");//set to string
            System.out.println( str );

//            Iterator<Set> iterator =  containerPortSet.iterator();
//            while (iterator.hasNext()) {
//                System.out.println(iterator.next());
//                String str2 = iterator.next();
//                System.out.println( str2 );
//            }
            //String containerPort = "8080" + "/tcp";//镜像默认端口
            String containerPort = str;//容器暴露端口
            String containerPortName = str.split( "/" )[0];//容器的预暴露端口名
            //final String[] ports = {"8080" +""};

            //将宿主机的端口 与 容器暴露端口 绑定
            final Map<String, List<PortBinding>> portBindings = new HashMap<String, List<PortBinding>>();
            List<PortBinding> hostPorts = new ArrayList<PortBinding>();
            hostPorts.add(PortBinding.of("0.0.0.0", exposedPort));
            portBindings.put(containerPort + "", hostPorts);


            HostConfig.Bind bind = new HostConfig.Bind() {
                @Override
                public String to() {
                    return "/usr/share/nginx/html";
                }

                @Override
                public String from() {
                    return "/home/zj/ppp";
                }

                @Override
                public Boolean readOnly() {
                    return true;
                }

                @Override
                public Boolean noCopy() {
                    return false;
                }

                @Override
                public Boolean selinuxLabeling() {
                    return false;
                }
            };

            final HostConfig hostConfig = HostConfig.builder()
                    .binds(bind)
                    .portBindings( portBindings )
                    .build();
            System.out.println( hostConfig );

            // Create container with exposed ports 创建带有暴露端口的容器
            List<String> list = new ArrayList<>();
            final ContainerConfig containerConfig = ContainerConfig.builder()
                    .hostConfig( hostConfig )
                    .image( imageName )
                    .exposedPorts( containerPortName )//暴露指定端口
                    //.volumes( "" )

                    .build();
            final ContainerCreation creation = docker.createContainer( containerConfig );

            final String id = creation.id();//获得容器的id

            System.out.println( creation );
            System.out.println( id );

            // Inspect container 获得容器的详细信息
            final ContainerInfo infoC = docker.inspectContainer( id );
            System.out.println( ">>>>>>>>>>>>>>>>>>>" );
            System.out.println( infoC );

            // Start container
            docker.startContainer( id );

            // Exec command inside running container with attached STDOUT and STDERR  执行命令在正运行容器带有附加的STDUT和STDER
            final String[] command = {"ls"};
            final ExecCreation execCreation = docker.execCreate(
                    id, command, DockerClient.ExecCreateParam.attachStdout() );
            final LogStream output = docker.execStart( execCreation.id() );
            final String execOutput = output.readFully();

            System.out.println( execOutput );

            // Kill container 杀死这个进程
            //docker.killContainer( id );

            // Remove container 删除容器
            //docker.removeContainer( id );

            // Close the docker client 关闭这个容器客户机
            docker.close();

            return infoC.toString();

        }catch (Exception e) {
            e.printStackTrace(); //printStackTrace()方法的意思是：在命令行打印异常信息在程序中出错的位置及原因
        }

        return null;
    }


    /**
     * @Auther: zj
     * @Date: 2018/7/2 10:49
     * @Description: kill a running container
     * @return
     */
    @GetMapping("/stopContainer")
    public String stopContainer(@RequestParam("containerId") String containerId) throws DockerException, InterruptedException {
        // Create a client  by using the builder 通过builder连接一个客户机
        final DockerClient docker = DefaultDockerClient.builder()
                .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                // Set various options
                .build();

        // List all running containers.
        final List<Container> containers = docker.listContainers();
        Integer status =0;
        for(Container container :containers) {
            if (container.id().equals(containerId )) {
                status+=1;
                break;
            }
        }
        if (status!=0) {
            System.out.println( "该容器正在运行" );
            docker.killContainer( containerId );
            return "停止该容器成功！";
        } else {
            System.out.println( "该容器没有运行" );
            return "该容器没有运行！";
        }
    }
    /**
     * @Auther: zj
     * @Date: 2018/7/2 10:59
     * @Description: start a inactive container
     * @return
     */
    @GetMapping("/startContainer")
    public String startContainer(@RequestParam("containerId") String containerId) throws DockerException, InterruptedException {
        // Create a client  by using the builder 通过builder连接一个客户机
        final DockerClient docker = DefaultDockerClient.builder()
                .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                // Set various options
                .build();

        // List all running containers.
        final List<Container> containers = docker.listContainers();
        Integer status =0;
        for (Container container:containers) {
            if (container.id().equals( containerId )) {
                status+=1;
                break;
            }
        }
        if (status!=0) {
            System.out.println( "该容器正在运行" );

            return "该容器已经运行！";
        } else {
            System.out.println( "该容器没有运行" );
            docker.startContainer( containerId );
            return "运行该容器成功！";
        }
    }

    /**
     * @Auther: zj
     * @Date: 2018/7/2 10:59
     * @Description: remove a inactive container
     * @param containerId
     * @return
     * @throws DockerException
     * @throws InterruptedException
     */
    @GetMapping("/removeContainer")
    public String removeContainer(@RequestParam("containerId") String containerId) throws DockerException, InterruptedException {
        // Create a client  by using the builder 通过builder连接一个客户机
        final DockerClient docker = DefaultDockerClient.builder()
                .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                // Set various options
                .build();

        // List all running containers.
        final List<Container> containers = docker.listContainers();
        Integer status =0;
        for (Container container:containers) {
            if (container.id().equals( containerId )) {
                status+=1;
                break;
            }
        }
        if (status!=0) {
            System.out.println( "该容器正在运行" );
            docker.killContainer( containerId );
            docker.removeContainer(containerId);
            return "成功删除该容器！";
        } else {
            System.out.println( "该容器没有运行" );
            docker.removeContainer( containerId );
            return "成功删除该容器！";
        }
    }


    /**
     * @Auther: zj
     * @Date: 2018/7/2 15:28
     * @Description: test mysql
     * @return
     */
    @GetMapping("/testMysql")
    public String testMysql(@RequestParam("containerId") String containerId) throws DockerException, InterruptedException {

        // Create a client  by using the builder 通过builder连接一个客户机
        final DockerClient docker = DefaultDockerClient.builder()
                .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                // Set various options
                .build();

        // Exec command inside running container with attached STDOUT and STDERR  执行命令在正运行容器带有附加的STDUT和STDER
        // TODO 还有bug！！！！！！！，未能成功实现功能
        final String[] command = {"mysql -uroot -p123456"};
        final ExecCreation execCreation = docker.execCreate(
                containerId, command, DockerClient.ExecCreateParam.attachStdout() );
        final LogStream output = docker.execStart( execCreation.id() );
        final String execOutput = output.readFully();

        System.out.println( execOutput );
        return null;
    }

    /**
     * @Auther: zj
     * @Date: 2018/7/2 15:28
     * @Description: Get container logs(获得指定容器的日志)
     * @return
     */
    @GetMapping("/getDockerLogs")
    public String getDockerLogs(@RequestParam("containerId") String containerId) throws DockerException, InterruptedException {
        // Create a client  by using the builder 通过builder连接一个客户机
        final DockerClient docker = DefaultDockerClient.builder()
                .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                // Set various options
                .build();

        final String logs;
        try (LogStream stream = docker.logs(containerId, DockerClient.LogsParam.stdout(), DockerClient.LogsParam.stderr())) {
            logs = stream.readFully();
            return logs;
        } catch (Exception e) {
            e.printStackTrace(); //printStackTrace()方法的意思是：在命令行打印异常信息在程序中出错的位置及原因
            return null;
        }

    }


    /**
     * @Auther: zj
     * @Date: 2018/7/4 10:28
     * @Description: create a container (Latest version)
     * @return
     * 注意env的格式，es:镜像是 mysql 时,env=MYSQL_ROOT_PASSWORD=123456
     *
     * nginxUpDir的格式，es:/root/dockerDir/aaa ,Todo /root/dockerDir/目录下一定要先建立aaa目录
     */
    @GetMapping("/createContainerLatestVersion")
    public String createContainerLatestVersion(@RequestParam("imageName") String imageName,
                                               @RequestParam("port") Integer modifyPort,
                                               @RequestParam(value = "env",required = false,defaultValue = "no env") String env,
                                               @RequestParam(value = "nginxUpDir",required = false,defaultValue = "no dir") String nginxupDir) throws DockerException, InterruptedException {

            // Create a client  by using the builder 通过builder连接一个客户机
            final DockerClient docker = DefaultDockerClient.builder()
                    // TODO ip地址自己修改
                    .uri( URI.create( "http://192.168.23.128:2375" ) ) //2375端口，是centos7打开的远程访问端口，自己可自行设计
                    // Set various options
                    .build();
            final List<Image> quxImages = docker.listImages( DockerClient.ListImagesParam.allImages());
            Integer status = 0;
            //System.out.println(imageName);
            for(Image quxImage:quxImages) {
                if (quxImage.repoTags().toString().equals( String.format( "[" +imageName.toString()+"]") )){
                    //System.out.println( "已存在" );
                    status= status +1;
                }
                else {
                    status = status;
                }
            }
            if(status !=0){
                System.out.println( "该镜像已存在" );
            }
            else {
                System.out.println( "该镜像不存在" );
                docker.pull( imageName );//拉取镜像
            }
            //docker.pull( imageName );
            System.out.println( "++++" );


            // 宿主机端口与暴露端口绑定
            Map<String, List<PortBinding>> portBindings = new HashMap<>(100);

            final ImageInfo info = docker.inspectImage(imageName);
            ImmutableSet<String> containerPortSet = info.containerConfig().exposedPorts();//获取镜像默认端口

            // 去除/tcp后的端口集合
            Set<String> realExportPorts = new HashSet<>();

            UnmodifiableIterator<String> iterator = containerPortSet.iterator();
            //镜像默认端口可能有多个，要循环绑定
            while(iterator.hasNext()) {
                // 取出暴露端口号,形如：80/tcp
                String exportPort = iterator.next();//容器暴露预端口
                // 取出去除/tcp后的端口号
                String tmp = exportPort.trim().split("/")[0];
                realExportPorts.add(tmp);

                // 捆绑端口
                List<PortBinding> hostPorts = new ArrayList<>();//
                // TODO 要随机分配 宿主机端口
                Integer hostPort = modifyPort;
                hostPorts.add(PortBinding.of("0.0.0.0", hostPort));
                portBindings.put(tmp, hostPorts);
            }

//            //String containerPort = "8080" + "/tcp";//镜像默认端口
//            String containerPort = str;//容器暴露端口
//            String containerPortName = str.split( "/" )[0];//容器的预暴露端口名
//            //final String[] ports = {"8080" +""};
//
//            //将宿主机的端口 与 容器暴露端口 绑定
//            final Map<String, List<PortBinding>> portBindings = new HashMap<String, List<PortBinding>>();
//            List<PortBinding> hostPorts = new ArrayList<PortBinding>();
//            hostPorts.add(PortBinding.of("0.0.0.0", exposedPort));
//            portBindings.put(containerPort + "", hostPorts);

        if (nginxupDir.equals( "no dir" )) { //没有指定nginx上传目录
            final HostConfig hostConfig = HostConfig.builder()
                    .portBindings( portBindings )
                    .build();

            System.out.println( hostConfig );

            if (env.equals( "no env" )) {//不设置环境变量
                // Create container with exposed ports 创建带有暴露端口的容器
                ContainerConfig containerConfig = ContainerConfig.builder()
                        .hostConfig( hostConfig )
                        .image( imageName )
                        .exposedPorts( realExportPorts )//暴露指定端口
                        .cmd( "sh", "-c", "while :; do sleep 1; done" )//让容器创建后不默认关闭
                        .build();
                final ContainerCreation creation = docker.createContainer( containerConfig );

                final String id = creation.id();//获得容器的id

                // Inspect container 获得容器的详细信息
                final ContainerInfo infoC = docker.inspectContainer( id );
                System.out.println( ">>>>>>>>>>>>>>>>>>>" );
                System.out.println( infoC );

                // Start container
                docker.startContainer( id );

                // Close the docker client 关闭这个容器客户机
                docker.close();

                return infoC.toString();
            } else {    //设置环境变量
                // Create container with exposed ports 创建带有暴露端口的容器
                ContainerConfig containerConfig = ContainerConfig.builder()
                        .hostConfig( hostConfig )
                        .image( imageName )
                        .exposedPorts( realExportPorts )//暴露指定端口
                        .cmd( "sh", "-c", "while :; do sleep 1; done" )//让容器创建后不默认关闭
                        .env(env) //设置环境变量
                        .build();
                final ContainerCreation creation = docker.createContainer( containerConfig );

                final String id = creation.id();//获得容器的id

                // Inspect container 获得容器的详细信息
                final ContainerInfo infoC = docker.inspectContainer( id );
                System.out.println( ">>>>>>>>>>>>>>>>>>>" );
                System.out.println( infoC );

                // Start container
                docker.startContainer( id );

                // Close the docker client 关闭这个容器客户机
                docker.close();

                return infoC.toString();
            }

        } else { //指定nginx上传目录
            HostConfig.Bind bind = new HostConfig.Bind() {
                @Override
                public String to() {
                    return "/usr/share/nginx/html";
                }

                @Override
                public String from() {
                    //TODO nginxupDir 应该事先根据用户id,创建用户自己的上传目录
                    return nginxupDir;
                }

                @Override
                public Boolean readOnly() {
                    return true;
                }

                @Override
                public Boolean noCopy() {
                    return false;
                }

                @Override
                public Boolean selinuxLabeling() {
                    return false;
                }
            };

            final HostConfig hostConfig = HostConfig.builder()
                    .binds( bind )
                    .portBindings( portBindings )
                    .build();

            System.out.println( hostConfig );

            if (env.equals( "no env" )) {//不设置环境变量
                // Create container with exposed ports 创建带有暴露端口的容器
                ContainerConfig containerConfig = ContainerConfig.builder()
                        .hostConfig( hostConfig )
                        .image( imageName )
                        .exposedPorts( realExportPorts )//暴露指定端口
                        .cmd( "sh", "-c", "while :; do sleep 1; done" )//让容器创建后不默认关闭
                        .build();
                final ContainerCreation creation = docker.createContainer( containerConfig );

                final String id = creation.id();//获得容器的id

                // Inspect container 获得容器的详细信息
                final ContainerInfo infoC = docker.inspectContainer( id );
                System.out.println( ">>>>>>>>>>>>>>>>>>《" );
                System.out.println( infoC );

                // Start container
                docker.startContainer( id );

                // Close the docker client 关闭这个容器客户机
                docker.close();

                return infoC.toString();
            } else {    //设置环境变量
                // Create container with exposed ports 创建带有暴露端口的容器
                ContainerConfig containerConfig = ContainerConfig.builder()
                        .hostConfig( hostConfig )
                        .image( imageName )
                        .exposedPorts( realExportPorts )//暴露指定端口
                        .cmd( "sh", "-c", "while :; do sleep 1; done" )//让容器创建后不默认关闭
                        .env(env) //设置环境变量
                        .build();
                final ContainerCreation creation = docker.createContainer( containerConfig );

                final String id = creation.id();//获得容器的id

                // Inspect container 获得容器的详细信息
                final ContainerInfo infoC = docker.inspectContainer( id );
                System.out.println( "《《《《《《《《《《" );
                System.out.println( infoC );

                // Start container
                docker.startContainer( id );

                // Close the docker client 关闭这个容器客户机
                docker.close();


                return infoC.toString();
            }

        }
//            // Exec command inside running container with attached STDOUT and STDERR  执行命令在正运行容器带有附加的STDUT和STDER
//            final String[] command = {"ls"};
//            final ExecCreation execCreation = docker.execCreate(
//                    id, command, DockerClient.ExecCreateParam.attachStdout() );
//            final LogStream output = docker.execStart( execCreation.id() );
//            final String execOutput = output.readFully();
//            System.out.println( execOutput
    }


}


